﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User05.Models;

namespace User05.Windows
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Window
    {
        private user05Entities _context = new user05Entities();
        public Authorization()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(IdNumbertxtbox.Text) || !IdNumbertxtbox.IsMaskCompleted || string.IsNullOrWhiteSpace(Passwordtxtbox.Text))
            {
                MessageBox.Show("Поля не могут быть пустыми!");
                return;
            }
            int kod_polzovatelya = int.Parse(IdNumbertxtbox.Text);
            string password = Passwordtxtbox.Text;
            try
            {
                var user = _context.polzovateli
                    .FirstOrDefault(u => u.kod_polzovatelya == kod_polzovatelya && u.parol == password);
                if(user == null)
                {
                    MessageBox.Show("Неверный логин или пароль. Введите корректные значения.");
                    return;
                }

                if (user.kod_roli == 1)
                {
                    AdminWindow adminWindow = new AdminWindow(user);
                    adminWindow.Show();
                    this.Close();
                }
                else if(user.kod_roli == 2)
                {

                }
                else
                {
                    MessageBox.Show("У вас нет доступа к системе.");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
