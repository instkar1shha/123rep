﻿using System;
using System.Linq;
using System.Windows;
using User05.Models;

namespace User05.Windows
{
    public partial class SuppliesWindow : Window
    {
        private user05Entities _context = new user05Entities();

        public SuppliesWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            var requestsData = _context.zayavki
                .Join(_context.meropriyatiya,
                    z => z.id_meropriyatiya,
                    m => m.kod_meropriyatiya,
                    (z, m) => new
                    {
                        z.id_zyavki,
                        z.data,
                        z.vremya,
                        z.id_klienta,
                        m.nazvaniye,
                        z.status
                    })
                .ToList();

            UsersDataGrid.ItemsSource = requestsData;
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку, Которую нужно удалить");
                return;
            }
                  

            dynamic selected = UsersDataGrid.SelectedItem;
            var request = _context.zayavki.Find(selected.id_zyavki);

            _context.zayavki.Remove(request);
            _context.SaveChanges();

            LoadData();
        }
    }
}