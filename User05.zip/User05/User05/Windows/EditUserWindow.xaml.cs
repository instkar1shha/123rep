﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User05.Models;

namespace User05.Windows
{
    /// <summary>
    /// Логика взаимодействия для EditUserWindow.xaml
    /// </summary>
    public partial class EditUserWindow : Window
    {
        private polzovateli _selecteduser;
        private user05Entities _context = new user05Entities();

        public EditUserWindow(polzovateli selecteduser)
        {
            InitializeComponent();
            _selecteduser = selecteduser;
            this.DataContext = this._selecteduser;
            IdUserTxtbox.Text = _selecteduser.kod_polzovatelya.ToString();
            PasswordTxtBox.Text = _selecteduser.parol.ToString();

            IdRoletxtbox.Text = _selecteduser.kod_roli.ToString();

        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            UsersListWindow usersListWindow = new UsersListWindow(_selecteduser);
            usersListWindow.Show();
            this.Close();
        }

        private void IdUserTxtbox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var typeofuser = _context.administratori
                    .FirstOrDefault(t => t.id_administratora == _selecteduser.kod_polzovatelya);
               
                _selecteduser.parol = PasswordTxtBox.Text;

                _context.polzovateli.AddOrUpdate(_selecteduser);
                _context.administratori.AddOrUpdate(typeofuser);
                _context.SaveChanges();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
