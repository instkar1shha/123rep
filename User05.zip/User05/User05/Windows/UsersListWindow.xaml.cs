﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User05.Models;

namespace User05.Windows
{
    /// <summary>
    /// Логика взаимодействия для UsersListWindow.xaml
    /// </summary>
    public partial class UsersListWindow : Window
    {
        private polzovateli _user;
        private user05Entities _context = new user05Entities();
        public UsersListWindow(polzovateli user)
        {
            InitializeComponent();
            _user = user;
            UsersListView.ItemsSource = _context.polzovateli.ToList();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminWindow adminWindow = new AdminWindow(_user);
            adminWindow.Show();
            this.Close();
        }

        private void UsersListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selecteduser = UsersListView.SelectedItem as polzovateli;
            EditUserWindow editUserWindow = new EditUserWindow(selecteduser);
            editUserWindow.Show();
            this.Close();
        }
    }
}
