﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User05.Models;

namespace User05.Windows
{
    /// <summary>
    /// Логика взаимодействия для AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        private polzovateli _user;
        public AdminWindow(polzovateli user)
        {
            InitializeComponent();
            _user = user;
        }

        private void ProfileAdminBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminProfileWindow adminProfileWindow = new AdminProfileWindow(_user);
            adminProfileWindow.Show();
            this.Close();
        }

        private void UsersBtn_Click(object sender, RoutedEventArgs e)
        {
            UsersListWindow usersListWindow = new UsersListWindow(_user);
            usersListWindow.Show();
            this.Close();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            Authorization authorization = new Authorization();
            authorization.Show();
            this.Close();
        }
    }
}
