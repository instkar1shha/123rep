﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User05.Models;

namespace User05.Windows
{
    /// <summary>
    /// Логика взаимодействия для AdminProfileWindow.xaml
    /// </summary>
    public partial class AdminProfileWindow : Window
    {
        private polzovateli _user;
        private user05Entities _context = new user05Entities();
        public AdminProfileWindow(polzovateli user)
        {
            InitializeComponent();
            _user = user;
            var administrator = _context.administratori
                .FirstOrDefault(a => a.id_administratora == _user.kod_polzovatelya);
            SurnameTxtBox.Text = administrator.familiya;
            NameTxtBox.Text = administrator.imya;
            PatronymicTxtBox.Text = administrator.otchestvo;
            YearOfWorktxtbox.Text = administrator.stazh.ToString();
            DateBirthDatePicker.SelectedDate = administrator.data_rozhdeniya;
            LoadPicture();
        }
        private void LoadPicture()
        {
            ProfileImg.Source = new BitmapImage(new Uri("pack://application:,,,/Resources/doc1.jpg"));
        }
        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            AdminWindow adminWindow = new AdminWindow(_user);
            adminWindow.Show();
            this.Close();
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DateBirthDatePicker_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = true;
            MessageBox.Show("Выберите дату из меню.");
        }

        private void DateBirthDatePicker_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            MessageBox.Show("Выберите дату из меню.");
        }

        private void SurnameTxtBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(char.IsLetter);
            MessageBox.Show("Можно вводить только буквы.");
        }
    }
}
